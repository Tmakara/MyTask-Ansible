# ZTP Logs
This directory will be filled with logs after each time the ZTP workflowhas been executed.