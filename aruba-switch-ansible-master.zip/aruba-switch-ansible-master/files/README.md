# Files 
This directory can be filled with files like Firmware (.swi) or certificates if certain workflows are used. THe documentation will tell you if it is needed.