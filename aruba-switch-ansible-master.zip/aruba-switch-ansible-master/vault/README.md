# Vault 
This directory has to be filled with Ansible vault files if you want to use the "arubaos_switch_firmware" workflow (See documentation).