## Custom Baseline Hardening Example ##

- A simplistic approach to scanning, remediation, verification and rollback using Ansible Tower
