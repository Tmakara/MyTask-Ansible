**Description of PR**
<!--- Describe what the PR holds -->

**Type of change**
<!--- Pick one below and delete the rest: -->

Feature Pull Request
Bugfix Pull Request
Docs Pull Request

**Fixes an issue**
<!--- If this PR fixes an issue, please mention it. -->
