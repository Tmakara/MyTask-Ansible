# Code of Conduct

The Code of Conduct from Ansible found [here](https://docs.ansible.com/ansible/devel/community/code_of_conduct.html) applies to this Ansible role as well.
